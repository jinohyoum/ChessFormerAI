#ifndef __AI__
#define __AI__

#include <stdint.h>
#include <unistd.h>
#include <stdbool.h>

void solve(char const *path, bool show_solution);

#endif
